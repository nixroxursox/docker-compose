<?php

use App\Control\rootController;
use App\Router;

$router = new Router();

$router->get('/', rootController::class, 'index');

$router->dispatch();
