<?php 

use Respect\Validate\Validation as v;
use Respect\Validate\Validator as v;









$app->get('/hello/{name}', function ($request, $response, $args) {
        return $response->write("Hello " . $args['name']);
    });



?>