<?php


class Scrub extends validation
{
    public string $data;
    public $formData;


    function __contruct () {
        $this->formData = $formData;
    }
    
    function scrub_formData ($formData) {
        $this->formData = $formData;
        return $this->formData;
    }
}


?>
