<?php 

use Respect\Validation\Validator as v;
use Respect\Validation\Exceptions\ValidationException as e;

try {
    $usernameValidator->assert('really messed up screen#name');
} catch(NestedValidationException $exception) {
    print_r(
        $exception->getMessages([
            'alnum' => '{{name}} must contain only letters and digits',
            'noWhitespace' => '{{name}} cannot contain spaces',
            'length' => '{{name}} must not have more than 15 chars',
        ])
    );
}


$nest_exc =  Array
(
    [alnum] => "really messed up screen#namemust contain only letters (a-z) and digits (0-9)",
    [noWhitespace] => "really messed up screen#name must not contain whitespace",
    [length] => "really messed up screen#name must have a length between 1 and 15"
);

// custom rules for username, password etc
$uname_val = v::create(
    new Rules\Alnum(),
    new Rules\NoWhitespace(),
    new Rules\Length(1, 15)
);



class DataCleanse
   {
    function __construct()
        {
            return $this->validator = new v;
        }   

    public static function html_clean($data)
        {
            try  {
                $data = trim($data);
                $data = stripslashes($data);
                $data = htmlspecialchars($data);
            }  catch(ValidationException $exception) {
                echo $exception->getMessage();
            }
            return $data;
        }







   }


$password_rules = v::length(12, 30) // Minimum 12, max 30 chars
                ->alnum()          // Must have letters/numbers (then add more specific checks)
                ->noWhitespace()   // No spaces
                ->not(v::in(['password', '123456', 'qwerty'])) // Avoid common weak passwords
                ->addRule(v::each(v::oneOf(
                    v::uppercase(),
                    v::lowercase(),
                    v::digit(),
                    v::specialChar()
                ))); // Ensure it has *some* variety, but length is primary

?>