<?php

require_once('../vendor/autoload.php');
require_once('../View/root.php');
require_once('../Control/root.php');


$dotenv = Dotenv\Dotenv::createImmutable('/var/www/html/ecom_mvc');
$dotenv->load();



$app = new Application();

include_once dirname(__DIR__) . "ecom_mvc/Router.php";

echo $app->run();


?>


<!-- // $router = require '../src/Routes/index.php'; -->
