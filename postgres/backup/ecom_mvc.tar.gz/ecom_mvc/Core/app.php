<?php 

class App {
    protected $control = 'root';
    protected $method = 'index';
    protected $params = [];

    public function __construct()
    {
        $url = $this->parseURL();
        
        // controller
        if( file_exists('../control/' . $url[0] . '.php') ) {
            $this->control = $url[0];
            unset($url[0]);
        }

        require_once '../control/' . $this->control . '.php';
        $this->control = new $this->control;

        // method
        if( isset($url[1]) ) {
            if( method_exists($this->control, $url[1]) ) {
                $this->method = $url[1];
                unset($url[1]);
            }
        }

        // params
        if( !empty($url) ) {
            $this->params = array_values($url);
        }

        // jalankan controller & method, serta kirimkan params jika ada
        call_user_func_array([$this->control, $this->method], $this->params);

    }

    public function parseURL()
    {
        if( isset($_GET['url']) ) {
            $url = rtrim($_GET['url'], '/');
            $url = filter_var($url, FILTER_SANITIZE_URL);
            $url = explode('/', $url);
            return $url;
        }
    }
}