<?php

use Doctrine\DBAL\Driver\PDO\PDOException;
use PHPUnit\Runner\ErrorException;


class DbTask {


    public function __construct()
    {
        set_error_handler(array($this, 'exceptions_error_handler'));
    }

    public function get_db() {
        try {

            $host="postgres.gc-pay.com";
            $port=5432;
            $socket="/tmp";
            $user="rocky";
            $password="test";
            $db="market";
        
            $pdo = new Pdo\CONNECT("pgsql:host=$socket;dbname=$db;", $user, $password, array(
                    \PDO::ATTR_PERSISTENT => true,
                    \PDO::ATTR_EMULATE_PREPARES => false,
                    \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION
            ));
        
        } catch (PDOException $e) {
            echo "Caught exception: " . $e->getMessage() . "<br>";
        }

        return $pdo;
    }

    public function commit()
        {
            return $this->pdo->commit();
        }


    public function rollBack()
    {
        return $this->pdo->rollBack();
    }

    public function kill_db()
        {
            return $pdo = null;
        }

    function exceptions_error_handler($severity, $message, $filename, $lineno)
        {
            throw new ErrorException($message, 0, $severity, $filename, $lineno);
        }

}



$newdb = new DB();
$newdb->get_db();

$sql = "SELECT id, name, email FROM users";
      $result = $newdb->execute($sql);
   


if ($result->num_rows > 0) {
  // output data of each row
  while($row = $result->fetch_assoc()) {
    echo "id: " . $row["id"]. " - Name: " . $row["name"]. " " . $row["email"]. "<br>";
  }
} else {
  echo "0 results";
}
$conn->close();


?>