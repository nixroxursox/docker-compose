<?php

require_once('DB/DbMaster.php');

$conn = new DbMaster();


$db = $conn->connect();

$sql = "insert into customers(first_name,last_name,username,email,active,password_hash) values (:first_name, :last_name, :username, :email, :active, :password_hash)";

$userInfo = array ( 
fname => 'rocky',
lname => 'allen',
username => 'rjallen',
email => 'nixrox@gmail.com',
active => 'True',
password => '123456',
password_hash => $hashed
);

$hashed = password_hash($userInfo[5], PASSWORD_DEFAULT);

$stmt = $db->prepare($sql);
$stmt->bindParam(':first_name', $fname);
$stmt->bindParam(':last_name', $lname);
$stmt->bindParam(':username', $username);
$stmt->bindParam(':email', $email);
$stmt->bindParam(':active', $active);
$stmt->bindParam(':password_hash', $hashed);


$result = $stmt->execute();
if($result){
    echo "success";
}else{
    echo "failed";
}


?>
