<?php



class PgConfig
{
    public static function secret(): string
    {
        return $_ENV["SECRET_KEY"] ?? "market";
    }

    public static function database_config(): array
    {
        return [
            "name"        => $_ENV["DB_NAME"],
            "password"    => $_ENV["DB_PASSWORD"],
            "user"        => $_ENV["DB_USER"],
            "host"        => $_ENV["DB_HOST"],
            "socket"      => $_ENV["DB_SOCKET"]
        ];
    }

    public static function dsn()
    {
        $options = array(PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_OBJ, PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION);
        $db_config = self::database_config();
        try  {
        $dsn = "pgsql:host={$db_config['socket']};dbname={$db_config['name']->$options}";
        } catch (PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
        return $dsn;
    }

    public static function password(): string
        {
            return $_ENV["DB_PASSWORD"];
        }

    public static function user(): string
        {
            return $_ENV["DB_USER"];
        }

    public static function api_key(): string
        {
            return $_ENV["X_API_KEY"];
        }
    public static function socket(): string
        {
            return $_ENV["DB_SOCKET"];
        }

}
