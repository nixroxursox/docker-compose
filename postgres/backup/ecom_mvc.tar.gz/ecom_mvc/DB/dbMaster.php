<?php

require_once("dbConfig.php");
use PDO\pgsql;



class DbMaster {


    protected string $dsn;
    protected string $password;
    protected string $u;



    public function __construct()
        {
            $conf = new PgConfig();
            $this->dsn = $conf->dsn();
            $this->password = $conf->password();
            $this->u = $conf->user();
        }

    static function connect()
        {
            $conf = new PgConfig();
            $dsn = $conf->dsn();
            $user = $conf->user();
            $password = $conf->password();
            $options = [
                \PDO::ATTR_ERRMODE => \PDO::ERRMODE_EXCEPTION,
                \PDO::ATTR_DEFAULT_FETCH_MODE => \PDO::FETCH_ASSOC,
                \PDO::ATTR_EMULATE_PREPARES => false,
                \PDO::PDO::ATTR_PERSISTENT => True
            ];
    try {
        $db = \PDO::connect($dsn, $user, $password, $options);
            
        } catch (PDOException $e) {
            die("Connection failed: " . $e->getMessage());
        }
            return $db;
    }

    protected static function setColumns(string $sql, array $columns): string
        {
            $implode = '`' . implode('`, `', $columns) . '`';

            return str_replace("{columns}", $implode, $sql);
        }

    protected static function setValues(string $sql, array $values): string
        {
            $implode = "'" . implode("', '", $values) . "'";

            return str_replace("{values}", $implode, $sql);
        }

    protected static function setId(string $sql, int|string $id): string
        {
            return str_replace("{id}", $id, $sql);
        }


    protected static function setParams(string $sql, array $data): string
        {
            $update_values = '';

            foreach ($data as $key => $value)
                $update_values .= "$key='$value', ";

            $update_values = rtrim($update_values, ', ');

            return str_replace("{sets}", $update_values, $sql);
        }
}





?>
