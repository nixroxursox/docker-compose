<?php

namespace EcomMvc\Control;

use EcomMvc\Control;

class rootControl extends Control
{
    public function index()
    {

        $this->render('index');
    }
}

?>
