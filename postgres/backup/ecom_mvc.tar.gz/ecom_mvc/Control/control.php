<?php

namespace ecom_mvc\Control;

class Controller extends control
{
    public function __construct() {}
}
