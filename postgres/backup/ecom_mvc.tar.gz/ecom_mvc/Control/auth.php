<?php

namespace ecom_mvc\Control;

use ecom_mvc\Exceptions\UserException;
use ecom_mvc\View\Hash;
use ecom_mvc\View\JWT;
use ecom_mvc\View\Request;
use ecom_mvc\View\Response;
use ecom_mvc\Model\User;
use Respect\Validator;

class AuthController extends Control
{
    public function login()
    {
        $data = Request::post();

        $validation = (new Validator())->make($data, [
            "email" => "required|max:255",
            "password" => "required",
        ]);

        $validation->validate();

        if ($validation->fails()) {
            return UserException::error("email and password required", 403);
        }

        if (!User::check($data["email"], $data["password"])) {
            return Response::json([
                "detail" => "login unsuccessful",
            ], 403);
        }

        return Response::json([
            "JWT_token" => JWT::encode([
                "email" => $data["email"],
                "password" => Hash::hash($data["password"]),
            ]),
        ]);
    }

    public function register()
    {
        $data = Request::post();

        $validation = (new Validator())->make($data, [
            "name" => "required|max:255",
            "email" => "required|max:255",
            "password" => "required",
            "role" => "required",
        ]);

        $validation->validate();

        if ($validation->fails()) {
            UserException::error("something went wrong", 403);
        }

        return User::create($data);
    }
}
