<?php
// Include the BaseController file if needed, depending on your project structure
// require_once 'BaseController.php'; 
namespace EcomMvc\Control;
use EcomMvc\Control;

class RootControl extends Control // Extends BaseController if one exists
{
    /**
     * The default action for the home page.
     * Corresponds to the URL: / (or /home/index)
     */
    public function index()
    {
        // 1. Interact with a Model (optional for a simple home page)
        // Example: $homeModel = $this->loadModel('HomeModel');
        // $data['welcomeMessage'] = $homeModel->getWelcomeMessage();

        // 2. Prepare data to pass to the View
        $data['title'] = "This i a data point";
        $data['content'] = "This is the content for the home page.";

        // 3. Load and render the View
        // The render method is often inherited from a BaseController
        $this->render('View/root', $data); 
        $this->render('index');
    }
}

?>