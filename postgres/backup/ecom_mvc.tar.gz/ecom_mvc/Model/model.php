<?php

namespace Model;

require_once("DB/DbMaster.php");



class Model
{
    public function __construct()
        {
            $conn = new DbMaster();
            $this->db = $conn->connect();
            return $this->db;
        }
        
}


?>
