<?php 

class User extends Model
{
    protected static string $get_all_customers = "SELECT username, id  FROM customers;";
    protected static string $get_by_id = "SELECT * FROM customers WHERE `id` = {id};";
    protected static string $delete_cust = "DELETE FROM customers WHERE `id` = {id};";
    protected static string $update_cust = "UPDATE customers SET {sets} WHERE `id` = {id};";
    protected static string $check_cust = "SELECT * FROM customers WHERE `email` = '{email}';";
    protected static string $create_cust = "INSERT INTO customers ({columns}) VALUES ({values});";


    public function __construct()
    {
        parent::__construct();
    }

    public static function all(): array|bool
    {
        new self;

        $sql = self::$get_all_customers;

        try {
            $stmt = $this->db->prepare($sql);
            $result = $stmt->execute();
        } catch (Exception $e) {
            return UserException::error($e->getMessage());
        }

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    public function get_by_id(int $id): array|bool
    {
        $sql = self::setId(self::$get_by_id, $id);

        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
        } catch (Exception $e) {
            return UserException::error($e->getMessage());
        }

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    public static function delete(int $id): string
    {
        new self;
        $sql = self::$delete_cust;
        $sql = self::setId($sql, $id);

        $stmt = $this->db->prepare($sql);

        try {
            if ($stmt->execute()) return Response::success("user deleted successfuly");
        } catch (Exception $e) {
            return UserException::error($e->getMessage());
        }
    }

    public static function update(int $id, array $data): array|bool
    {
        new self;

        $sql = self::setId(self::$update_cust, $id);
        $sql = self::setParams($sql, $data);


        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
        } catch (Exception $e) {
            return UserException::error($e->getMessage());
        }

        return self::get_by_id($id);
    }

    public static function check(string $email, string $password): bool
    {
        new self;

        $sql = self::$check_cust;
        $sql = self::setEmail($sql, $email);

        $stmt = $this->db->prepare($sql);
        try {
            $stmt->execute();
        } catch (Exception $e) {
            UserException::error($e->getMessage(), 500);
        }

        if ($stmt->rowCount() == 0) UserException::error("something went wrong in your credentials", 403);

        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        return self::_check($user, $email, $password);
    }

    protected static function setEmail(string $sql, string $email): string
    {
        return str_replace("{email}", $email, $sql);
    }

    private static function _check(array $user, string $email, string $password): bool
    {
        if ($user["email"] == $email && Hash::verify($password, $user["password"])) {
            return true;
        }
        return false;
    }

    public static function create(array $data): array
    {
        new self;

        unset($data["id"]);
        $sql = self::$create_cust;
        $sql = self::setColumns($sql, array_keys($data));
        $sql = self::setValues($sql, array_values($data));

        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute();
        } catch (Exception $e) {
            return UserException::error($e->getMessage());
        }

        return self::get_by_id(self::$db->lastInsertId()); 
    }
}


class cust_manage extends Model 
    {

    public $id;
    public $first_name;
    public  $last_name;
    public $username;
    public $email;
    public $active;
    public $password;
    public $ddress_line1;
    public $ddress_line2;
    public $city;
    public $state;
    public $postal_code;
    public $phone_number;
    public $dial_code;
    public $db_tables;

    protected static string $register_customer = "INSERT INTO customers (first_name, last_name, username, email, active, password) VALUES (:id, :first_name, :last_name, :username, :email, :active, :password )";
    protected static string $register_customer_address = "INSERT INTO customer_addresses (customer_id, address_line1, address_line2, city, state, postal_code, phone_number, dial_code) VALUES (:id, :address_line1, :address_line2, :city, :state, :postal_code, :phone_number, :dial_code)";

    public function   __construct($id, $first_name, $last_name, $username, $email, $active, $password, $address_line1, $address_line2, $city, $State,$postal_code,$phone_number,$dial_code)       
    {
        $this->id = $id;
        $this->first_name = $first_name;
        $this->last_name = $last_name;
        $this->username = $username;
        $this->email = $email;
        $this->active = $active;
        $this->password = $password;
        $this->address_line1 = $address_line1;
        $this->address_line2 = $address_line2;
        $this->city = $city;
        $this->statte = $State;
        $this->postal_code = $postal_code;
        $this->phone_number = $phone_number;
        $this->dial_code = $dial_code;
        
    }


    public function get_array_post(): array
    {
        return [
            "fname"          => $this->first_name,
            "lname"          => $this->last_name,
            "username"       => $this->username,
            "email"          => $this->email,
            "password"       => $this->password,
            "active"         => $this->active,
            "address1"       => $this->address_line1,
            "address2"       => $this->address_line2,
            "city"           => $this->city,
            "state"          => $this->state,
            "zipcode"        => $this->postal_code,
            "phone"          => $this->phone_number,
            "prefix"         => $this->dial_code,
        ];
    }

    public function reg_customer(array $data): bool
    {
        $this->db_tables = "customers, customer_addresses";

        try {
            $stmt = $this->db->prepare($sql);
            $stmt->execute($data);
        } catch (Exception $e) {
            return UserException::error($e->getMessage());
        }}


    }


?>