<!DOCTYPE html>

<?php  

require_once('../Control/root.php');

?>

<html>
<head>
    <title><?php echo $title; ?></title>
</head>
<body>

    <p><?php echo $content; ?></p>
</body>
</html>

