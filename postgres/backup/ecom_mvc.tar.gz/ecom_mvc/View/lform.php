
<form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
   <label for="uname">Enter your Username:</label>
   <input type="text" id="uname" name="uname">
   <label for="password">Enter your Password:</label>
   <input type="text" id="password" name="password">
   <input type="submit">
</form>