<html>
    <body>
    <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]);?>
    <?php 
        require_once 'HTML/QuickForm2.php';
        require_once 'HTML/QuickForm2/Controller.php';
        require_once 'HTML/QuickForm2/Controller/Action.php';
        
    
    
        $form = new HTML_QuickForm2('loginForm');
        $form->setDefaults(array('username' => '', 'password' => '', ));
        $form->addElement('header', null, 'QuickForm tutorial example');
        $form->addElement('text', 'uname', 'Enter your Username:', array('size' => 50, 'maxlength' => 255));
        $form->addElement('text', 'password', 'Enter your Password:', array('size' => 50, 'maxlength' => 255));
        $form->addElement('submit', null, 'Send');

        // Define filters and validation rules
        $form->applyFilter('uname', 'trim');
        $form->applyFilter('passwword', 'trim');
        $form->addRule('uname', 'Please enter your name', 'required', null, 'client');
        $form->addRule('password', 'Please enter your Password', 'required', null, 'client');

        // Try to validate a form
        if ($form->validate()) {
            echo '<h1>Hello, ' . htmlspecialchars($form->exportValue('uname')) . '!</h1>';
            echo '<h1>Hello, ' . htmlspecialchars($form->exportValue('password')) . '!</h1>';
            exit;
        }

        // Output the form
        $form->display();

    ?>      
    </body>
    